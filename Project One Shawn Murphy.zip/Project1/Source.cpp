#include <iostream>
#include <string>
using namespace std;
//Global hour minute and second variables to use for clock
int h = 0;
int m = 0;
int s = 0;

string GetTimeOutput (unsigned int n) {
	string time = to_string(n);
	if (n < 10) {
		time = '0' + to_string(n);
	}
	return time;
}
string StringFormat(size_t n, char c) {
	string output = "";
	for (std::size_t i = 0; i < n; ++i) {
		output.push_back(c);
	}
	return output;
}

string formatTime24(unsigned int h, unsigned int m, unsigned int s) {
	string hour = GetTimeOutput(h); //Time output formatting for two digits
	string minute = GetTimeOutput(m); //Time output formatting for two digits
	string seconds = GetTimeOutput(s); //Time output formatting for two digits
	string time;
	time = hour + ":" + minute + ":" + seconds; //Putting together all the time outputs to make clock face
	return time;
}

string formatTime12(unsigned int hr, unsigned int m, unsigned int s) {
	string timeDay;
	string hour;
	string min;
	string sec;
	string time;
	if (h > 12) { //Afternoon conditional
		hour = GetTimeOutput(h - 12);
		timeDay = "P M";
	}
	else if (h - 12 == 0) { //Noon conditional
		hour = GetTimeOutput(h);
		timeDay = "P M";
	}
	else { //Morning Default
		hour = GetTimeOutput(h);
		timeDay = "A M";
	}
	
	min = GetTimeOutput(m);//Time output formatting for two digits
	sec = GetTimeOutput(s);//Time output formatting for two digits
	
	time = hour + ":" + min + ":" + sec + " " + timeDay; //Formatting the output of the time
	return time;
}

void printMenu(const char* strings[], unsigned int numStrings, unsigned char width) {
	
	int i;
	cout << StringFormat(width, '*') << endl;
	string s;
	s = strings[0];
	int endSpaces = width - (7 + s.length());
	cout << "* " << 1 << " - " << s << StringFormat(endSpaces, ' ') << "*" << endl;
	for (i = 1; i < numStrings; ++i) {
		s = strings[i];
		endSpaces = width - (7 + s.length());
		cout << endl;
		cout << "* " << i + 1 << " - " << s << StringFormat(endSpaces, ' ') << "*" << endl;
	}
	cout << StringFormat(width, '*') << endl;
}

unsigned int getMenuChoice(unsigned int maxChoice) {
	unsigned int userInput;
	cin >> userInput;
	while ((userInput < 1) || (userInput > maxChoice)) {
		cin >> userInput;

	}
	return userInput;
}

void setHour(int hour) {
	int& hr = hour;
	h = hr;
}

void setMinute(int minute) {
	int& min = minute;
	m = min;
}

void setSecond(int second) {
	int& sec = second;
	s = sec;
}

int getHour() {
	return h;
}

int getMinute() {
	return m;
}

int getSecond() {
	return s;
}

void addOneHour() {
	int hour;
	hour = getHour();
	if ((hour >= 0) && (hour < 23)) {
		hour += 1;
		setHour(hour);
	}
	else if (hour == 23) {
		hour = 0;
		setHour(hour);
	}
}

void addOneMinute() {
	int min;
	min = getMinute();
	if ((min >= 0) && (min < 59)) {
		min += 1;
		setMinute(min);
	}
	else if (min == 59) {
		min = 0;
		setMinute(min);
		addOneHour();
	}
}

void addOneSecond() {
	int second;
	second = getSecond();
	if ((second >= 0) && (second < 59)) {
		second += 1;
		setSecond(second);
	}
	else if (second == 59) {
		second = 0;
		setSecond(second);
		addOneMinute();
	}
}

void displayClocks(unsigned int h, unsigned int m, unsigned int s) {
	//Displays the clock face after each menu input and at beginning of the program
	cout << StringFormat(27, '*') << StringFormat(3, ' ') << StringFormat(27, '*') << endl;
	cout << StringFormat(1, '*') << StringFormat(6, ' ') << "12-HOUR CLOCK" << StringFormat(6, ' ') << StringFormat(1, '*') << StringFormat(3, ' ');
	cout << StringFormat(1, '*') << StringFormat(6, ' ') << "24-HOUR CLOCK" << StringFormat(6, ' ') << StringFormat(1, '*') << endl;
	cout << endl;
	cout << StringFormat(1, '*') << StringFormat(6, ' ') << formatTime12(h, m, s) << StringFormat(7, ' ') << StringFormat(1, '*') << StringFormat(3, ' ');
	cout << StringFormat(1, '*') << StringFormat(8, ' ') << formatTime24(h, m, s) << StringFormat(9, ' ') << StringFormat(1, '*') << endl;
	cout << StringFormat(27, '*') << StringFormat(3, ' ') << StringFormat(27, '*') << endl;
}

void mainMenu() {
	//Main processes of the clock mainly consisting of the while loop of adding hours minutes and seconds
	int userIn;
	const char * choices [4] = {"Add One Hour", "Add One Minute", "Add One Second", "Exit Program"};
	printMenu(choices, 4, 27);
	userIn = getMenuChoice(4);
	while (userIn != 4) {
		if (userIn == 1) {
			addOneHour();
		}
		else if (userIn == 2) {
			addOneMinute();
		}
		else {
			addOneSecond();
		}
		displayClocks(h, m, s);
		printMenu(choices, 4, 27);
		userIn = getMenuChoice(4);
	}
}

int main() {
	displayClocks(h, m, s);
	mainMenu();
	




	return 0;
}